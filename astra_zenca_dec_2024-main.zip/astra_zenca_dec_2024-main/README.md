CRUD Example Edit Solution is Added , go through the code and extract methods and make a neat code by avoiding repeated  code.

